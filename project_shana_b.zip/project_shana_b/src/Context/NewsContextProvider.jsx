import React, { createContext, useEffect, useState } from 'react'

export const NewsContext = createContext()

export default function NewsContextProvider(props) {



    const [news, setNews] = useState(
        JSON.parse(localStorage.getItem('NewsLocalStorage')) ||
        [
            { id: 0, mainImage: "https://images-ext-1.discordapp.net/external/wKgB3blQu9C2IB_4FFE6QgkqeSFYvOyclhKTFuVaIDI/https/images4.alphacoders.com/103/thumb-1920-1035777.jpg?width=810&height=456", secondImage: "https://cdn.pixabay.com/photo/2015/04/23/22/00/tree-736885__480.jpg", title: "Todorki Pop", firstParagraph: "he readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distributiok like readable English. Many e editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).", secondParagraph: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. Thmal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like)." },
            { id: 1, mainImage: "https://images-ext-2.discordapp.net/external/K0gja476dP9r_6Of83Xm0kyae5dThx5eTIWrtkDvBg0/https/wallpapercave.com/wp/wp4528997.jpg?width=810&height=456", secondImage: "https://www.simplilearn.com/ice9/free_resources_article_thumb/what_is_image_Processing.jpg", title: "Deku Pop", firstParagraph: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distri,. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).", secondParagraph: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like)." }
        ]
    )

    const [newOpenInBig, setnewOpenInBig] = useState({ id: null, mainImage: null, secondImage: null, firstParagraph: null, secondParagraph: null })




    const DeleteFromNews = (id) => {
        let updatedNews = news.filter(soloNew => soloNew.id !== id);
        setNews(updatedNews)
    }


    const addToNews = (mainImage, secondImage, title, firstParagraph, secondParagraph) => {
        if (mainImage === "" || secondImage === "" || title === "" || firstParagraph === "" || secondParagraph === "") {
            return "MessegeSomethingempty"
        }
        if (firstParagraph.length > 420 || secondParagraph.length > 420) {
            return "Messegeyourparagraphtoolong"
        }
        let newNews = { id: news.length + 1, mainImage, secondImage, title, firstParagraph, secondParagraph }
        let allNews = [...news, newNews]
        setNews(allNews)
        return "MessegeNewsAdd"

    }


    const OpenByIdInBigNews = (id) => {
        let openNew = news.find(avi => avi.id === id)
        return openNew;





    }






    useEffect(() => {
        const updateLocalStorage = () => {
            localStorage.setItem('NewsLocalStorage', JSON.stringify(news));
        };
        window.addEventListener('beforeunload', updateLocalStorage)
        return () => {
            window.removeEventListener('beforeunload', updateLocalStorage)
        };
    }, [news]);






    return (
        <NewsContext.Provider value={{ news, DeleteFromNews, addToNews, OpenByIdInBigNews, setnewOpenInBig, newOpenInBig }}>
            {props.children}

        </NewsContext.Provider>
    )
}
