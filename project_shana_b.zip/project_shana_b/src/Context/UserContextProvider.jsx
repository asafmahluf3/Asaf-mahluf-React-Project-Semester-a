import React, { createContext, useEffect, useState } from 'react'

export const UserContext = createContext()

export default function UserContextProvider(props) {

  const [users, setUsers] = useState(
    JSON.parse(localStorage.getItem('UserContext')) ||
    [{ email: "yair161643@gmail.com", password: "1234567", name: "Yair" },
    { email: "asafmahluf2@gmail.com", password: "1234567", name: "Asaf" }]
  )

  const [loginOrProfile, setloginOrProfile] = useState(JSON.parse(sessionStorage.getItem('forNavBar')) || "/login")

  const [currentUser, setcurrentUser] = useState(
    JSON.parse(sessionStorage.getItem('CurrentUserLocalStorage')) ||
    null) // משתנה של משתמש מחובר


  const [adminIsConnect, setadminIsConnect] = useState(
    JSON.parse(sessionStorage.getItem('adminIsConnectStorage')) ||
    false
  )






  // -----------------  מהרשמה לרשימה
  const fromRegisterToUsersList = (email, password, name) => {
    let newUser = { email, password, name };
    let ifExistUser = users.find(avi => avi.email === email)
    if (ifExistUser !== null && ifExistUser !== undefined) { // אם הוא מצא את המייל כחלק מהרשימה הכוונה שקיים משתמש כזה, אז יחזיר אמת
      return (true)
    }
    let newUsers = [...users, newUser];
    setUsers(newUsers);
  }

  // -----------------  בדיקה אחרי התחברות אם קיים משתמש כזה במערכת
  const fromLoginToCheckIfExist = (userEmail, password) => {
    let newUser = users.find(avi => avi.email === userEmail && avi.password === password)
    return newUser
  }

  useEffect(() => {
    console.log('currentUser', currentUser);

  }, [currentUser])



  useEffect(() => {
    const updateLocalStorage = () => {
      localStorage.setItem('UserContext', JSON.stringify(users));
    };
    window.addEventListener('beforeunload', updateLocalStorage)
    return () => {
      window.removeEventListener('beforeunload', updateLocalStorage)
    };
  }, [users]);




  useEffect(() => {
    const updateSessionStorage = () => {
      sessionStorage.setItem('CurrentUserLocalStorage', JSON.stringify(currentUser));
    };
    window.addEventListener('beforeunload', updateSessionStorage)
    return () => {
      window.removeEventListener('beforeunload', updateSessionStorage)
    };
  }, [currentUser]);



  useEffect(() => {
    const updateSessionStorage = () => {
      sessionStorage.setItem('forNavBar', JSON.stringify(loginOrProfile));
    };
    window.addEventListener('beforeunload', updateSessionStorage)
    return () => {
      window.removeEventListener('beforeunload', updateSessionStorage)
    };
  }, [loginOrProfile]);




  useEffect(() => {
    const updateSessionStorage = () => {
      sessionStorage.setItem('forNavBar', JSON.stringify(adminIsConnect));
    };
    window.addEventListener('beforeunload', updateSessionStorage)
    return () => {
      window.removeEventListener('beforeunload', updateSessionStorage)
    };
  }, [adminIsConnect]);





  return (
    <UserContext.Provider value={{ currentUser, setcurrentUser, users, setadminIsConnect, adminIsConnect, fromRegisterToUsersList, fromLoginToCheckIfExist, loginOrProfile, setloginOrProfile }}>
      {props.children}

    </UserContext.Provider>
  )
}
