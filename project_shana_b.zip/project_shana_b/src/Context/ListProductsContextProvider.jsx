import React, { createContext, useContext, useEffect, useState } from 'react'
import { UserContext } from './UserContextProvider'

export const ProductsContext = createContext()


export default function ListProductsContextProvider(props) {

    const { currentUser } = useContext(UserContext)



    const [items, setitems] = useState
        (
            JSON.parse(localStorage.getItem('itemsShopLocalStorage')) ||
            [
                { id: 0, name: "Naruto", price: 100, img: "https://kingeekil.com/Cat_490798_2514.jpg" },
                { id: 1, name: "Sasuke", price: 200, img: "https://m.media-amazon.com/images/I/614xrTNiCsL._AC_UF894,1000_QL80_.jpg" },
                { id: 2, name: "Kakashi susano", price: 300, img: "https://pop-figures.com/media/img/figurine/1015-funko-pop-figure-naruto-shippuden-kakashi-perfect-susano-o-box.jpg" },
                { id: 3, name: "Mewto", price: 120, img: "https://d3m9l0v76dty0.cloudfront.net/system/photos/9715308/large/59dd35d3c87d9f8b154842bc81f6f181.jpg" },
                { id: 4, name: "Killua", price: 60, img: "https://cnv.co.il/content/images/thumbs/0006766_-hunter-x-hunter-killua-zoldyck-with-yoyo-exclusive-pop_560.jpeg" },
                { id: 5, name: "All might", price: 75, img: "https://www.katom.shop/wp-content/uploads/2022/11/889698123815.jpg" },
                { id: 6, name: "Zenitsu", price: 150, img: "https://www.funpo.co.il/images/thumbs/0005957_funko-pop-zenitsu-agatsuma-demon-slayer-869-_480.jpeg" }
            ]
        )

    const [itemsInCart, setCartItems] = useState
        (
            JSON.parse(sessionStorage.getItem('cartItemsSessionStorage')) || []
        )


    const [totalPrice, settotalPrice] = useState(0)

    const addToItemsFromAddProduct = (name, price, img) => {
        let newProduct = { id: items.length + 1, name, price, img }
        let allItems = [...items, newProduct]
        setitems(allItems)
    }


    const removeFromItems = (id) => {
        let updatedItems = items.filter(item => item.id !== id);
        setitems(updatedItems);
    }


    useEffect(() => {
        const updateLocalStorage = () => {
            localStorage.setItem('itemsShopLocalStorage', JSON.stringify(items));
        };
        window.addEventListener('beforeunload', updateLocalStorage)
        return () => {
            window.removeEventListener('beforeunload', updateLocalStorage)
        };
    }, [items]);






    useEffect(() => {
        const updateSessionStorage = () => {
            sessionStorage.setItem('cartItemsSessionStorage', JSON.stringify(itemsInCart));
        };
        window.addEventListener('beforeunload', updateSessionStorage)
        return () => {
            window.removeEventListener('beforeunload', updateSessionStorage)
        };
    }, [itemsInCart]);






    const removeFromitemsInCart = (id, price) => {
        let updatedItems = itemsInCart.filter(item => item.id !== id);
        setCartItems(updatedItems);
        settotalPrice(totalPrice - price)
    }


    const addToCart = (name, price, img) => {
        if (currentUser === undefined || currentUser === null) {
            return "ShowMessageRegisterbeforebuying"
        }
        else {
            let newProductToCart = { id: itemsInCart.length + 1, name, price, img }
            let allItems = [...itemsInCart, newProductToCart]
            setCartItems(allItems)
            parseInt(totalPrice)
            settotalPrice(totalPrice + price)

            return "ShowMessageItemAdd"
        }

    }


    return (
        <ProductsContext.Provider value={{ items, itemsInCart, totalPrice, removeFromItems, addToCart, removeFromitemsInCart, addToItemsFromAddProduct }}>
            {props.children}
        </ProductsContext.Provider>
    )
}
