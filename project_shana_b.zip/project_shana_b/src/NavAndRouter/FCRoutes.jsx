import React from 'react'
import { Route, Routes } from 'react-router-dom'
import FCAdminAddItem from '../Pages/FCAdminAddItem'
import FCAdminAddNews from '../Pages/FCAdminAddNews'
import FCCart from '../Pages/FCCart'
import FCHomePage from '../Pages/FCHomePage'
import FCLogin from '../Pages/FCLogin'
import FCNews from '../Pages/FCNews'
import FCProfile from '../Pages/FCProfile'
import FCRegister from '../Pages/FCRegister'
import FCShop from '../Pages/FCShop'
import FCNewOpen from '../Pages/FCNewOpen'
import FCGamePage from '../Pages/FCGamePage'



export default function FCRoutes() {
    return (
        <div style={{ margin: 20, fontSize: 25, color: 'red' }}>
            <Routes>
                <Route path='/' element={<FCHomePage />} />
                <Route path='/register' element={<FCRegister />} />
                <Route path='/login' element={<FCLogin />} />
                <Route path='/profile' element={<FCProfile />} />
                <Route path='/shop' element={<FCShop />} />
                <Route path='/cart' element={<FCCart />} />
                <Route path='/news' element={<FCNews />} />
                <Route path='/addnews' element={<FCAdminAddNews />} />
                <Route path='/addproduct' element={<FCAdminAddItem />} />
                <Route path='/openNew' element={<FCNewOpen />} />
                <Route path='/gamePage' element={<FCGamePage/>}/>




            </Routes>
        </div>
    )
}
