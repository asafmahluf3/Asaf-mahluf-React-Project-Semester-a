import React, { useContext } from 'react'
import { Link } from 'react-router-dom';
import { UserContext } from '../Context/UserContextProvider';
import './Nav.css';

export default function FCNavbar() {
    const { loginOrProfile, adminIsConnect } = useContext(UserContext)

    return (
        <div className="navbar">
            <Link className="logo" to={"/"}>Home Page</Link>
            <div style={{marginLeft:"29%"}} className="navbar-right">
                <Link className="navbar a" to={"/shop"}>𝕊𝕙𝕠𝕡</Link>
                <Link className="navbar a" to={"/news"}>ℕ𝕖𝕨𝕤</Link>
                <Link className="navbar a" to={"/gamePage"}>𝔾𝕒𝕞𝕖 ℙ𝕒𝕘𝕖</Link>
                {adminIsConnect && (
                    <>
                        <Link className="navbar a" to={"/addnews"}>𝔸𝕕𝕕 ℕ𝕖𝕨𝕤</Link>
                        <Link className="navbar a" to={"/addproduct"}>𝔸𝕕𝕕 ℙ𝕣𝕠𝕕𝕦𝕔𝕥</Link>
                    </>
                )}
            </div>
            <Link className="navbar-icon" to={loginOrProfile}><img width={"10%"} style={{marginLeft:"90%"}} src="https://cdn.discordapp.com/attachments/1069663517759766578/1079406641558065233/corporate-user-icon.png" alt="" /></Link>
        </div>
    )
}
//