import React, { useContext } from 'react'
import { useNavigate } from 'react-router-dom';
import { NewsContext } from '../Context/NewsContextProvider'
import { Link } from 'react-router-dom';
import { UserContext } from '../Context/UserContextProvider';



export default function FCSoloNew(props) {
    const navigate = useNavigate();


    const { setnewOpenInBig, OpenByIdInBigNews,DeleteFromNews } = useContext(NewsContext)
    const { adminIsConnect } = useContext(UserContext)

    


    // const btnDeleteSoloNew = () => {
    //     DeleteFromNews(props.id)
    // }


    const btnOpenBig = () => {
        let newOpen = OpenByIdInBigNews(props.id)
        setnewOpenInBig(newOpen)
        navigate("/openNew")
    }

    const btnDeleteNew = () => {
        DeleteFromNews(props.id)
    }
    




    return (
        <div>
            <Link onClick={() => btnOpenBig(props)} style={{ color: "black", textDecoration: "none" }} to={"/openNew"} >
                <div>
                    <h1>{props.title}</h1>
                </div>

                <div style={{ width: "100%", borderRadius: "10px", color: "lightblue", display: "flex", gap: "25px", alignItems: "center", fontSize: "22px", justifyContent: "center" }}>
                    <img style={{ width: "30%" }} src={props.mainImage} alt="" />
                    {props.firstParagraph} <br />
                    {/* <button onClick={() => btnDeleteSoloNew(props)}> */}
                    {/* </button> */}
                </div>

            </Link>

            <button hidden={!adminIsConnect} onClick={() => btnDeleteNew(props)}>❌</button>

            <hr style={{ marginTop: "10%", marginBottom: "-5%", width: "65%", border: "1px solid rgba(0, 0, 0, 0.333)" }} />
        </div>


    )
}




