import React, { useContext, useState } from 'react'
import './Product.css';
import { ProductsContext } from '../Context/ListProductsContextProvider'
import { UserContext } from '../Context/UserContextProvider'
import { Snackbar } from '@mui/material';

export default function FCProduct(props) {


  const { removeFromItems, addToCart } = useContext(ProductsContext)
  const { adminIsConnect } = useContext(UserContext)

  const [open, setOpen] = useState(false)
  const [message, setMessage] = useState('')
  





  const btnClickAddToCart = () => {
    let priceInt = parseInt(props.price)
    let CheckAlert = addToCart(props.name, priceInt, props.img)

    if (CheckAlert === "ShowMessageRegisterbeforebuying") {
      setOpen(true)
      setMessage("Register before buying")
    }
    else if (CheckAlert === "ShowMessageItemAdd") {
      setOpen(true)
      setMessage("Item Add")
    }

  }


  const btnDeleteFromShop = () => {
    removeFromItems(props.id)
  }

  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return
    }
    setOpen(false)
  }

  return (
    <div>
      <div id="container">
        <div class="product-details">

          <h1>{props.name}</h1>


          <div class="control">
            <button class="btn">
              <span class="price">{props.price}$</span>
              <span class="shopping-cart"><i class="fa fa-shopping-cart" aria-hidden="true"></i></span>
              <span onClick={() => btnClickAddToCart(props)} class="buy">Buy Now</span>
              <button style={{ background: "none", border: "0px solid" }} hidden={!adminIsConnect} onClick={() => btnDeleteFromShop(props)}>❌</button>
            </button>
          </div>


        </div>

        <div class="product-image">
          <img style={{ width: "100%", height: "100%" }} src={props.img} alt="" /> <br />
        </div>


      </div>
      <Snackbar
        style={{ marginTop: '220px' }}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
        open={open}
        autoHideDuration={1000}
        onClose={handleClose}
        message={message}
      />
    </div>
  )
}


