import { Button, Snackbar, TextField } from '@mui/material';
import React, { useContext, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { UserContext } from '../Context/UserContextProvider';


export default function FCRegister() {
    const navigate = useNavigate();

    const { fromRegisterToUsersList } = useContext(UserContext);
    const [email, setEmail] = useState('')
    const [password1, setPassword1] = useState('')
    const [password2, setPassword2] = useState('')
    const [name, setName] = useState('')
    const [flagCheckEmail, setflagCheckEmail] = useState(false)
    const [flagCheckPassword, setflagCheckPassword] = useState(false)
    const [flagName, setFlagName] = useState(false)
    const [flagHidden, setFlagHidden] = useState(true)

    const [open, setOpen] = useState(false)
    const [message, setMessage] = useState('')


    const regexEmail = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/
    const regexPassword = /^.{6,}$/





    const btnSubmitRegister = () => {
        let goodEmail = true
        let goodPassword = true
        if (password1 !== password2) {
            setMessage("PASSWORD DIFFERENT")
            setOpen(true)
            goodPassword = false
        }
        if (!(regexEmail.test(email))) {
            setMessage("Email Not good")
            setOpen(true)
            goodEmail = false
        }
        if (!(regexPassword.test(password1))) {

            setMessage("Password Not good")
            setOpen(true)
            goodPassword = false
        }
        if (goodEmail && goodPassword) {
            let userExistInUsers = fromRegisterToUsersList(email, password1, name)
            if (!userExistInUsers) { // אם אין משתמש כזה כחלק מרשימת היוזרים, המשתמש יכנס ללוגין
                navigate('/login')
            }
            else if (userExistInUsers) { // אם יש משתמש כזה ברשימת היוזרים לא יתן לו להרשם

                setMessage("TAFUS")
                setOpen(true)
            }
        }
    }

    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
            return
        }
        setOpen(false)
    }


    return (
        <div style={{ width: '700px', background: "linear-gradient(to right, rgb(255, 255, 255), #835B00)" }}>

            <h1 style={{ color: "lightblue" }}>𝓡𝓮𝓰𝓲𝓼𝓽𝓮𝓻</h1>


            <div style={{ display: "flex", flexDirection: "column", gap: "20px", width: "50%", paddingLeft: "25%" }}>


                <TextField onChange={(e) => {
                    setEmail(e.target.value)
                    if (regexEmail.test(e.target.value)) {
                        setflagCheckEmail(true)
                    }
                }} id="outlined-basic" label="Email" variant="outlined"></TextField>


                <TextField onChange={(e) => setPassword1(e.target.value)} type={"password"} id="outlined-basic" label="Password" variant="outlined"></TextField>

                <TextField onChange={(e) => {
                    setPassword2(e.target.value);
                    setflagCheckPassword(true)
                }} style={{ backgroundColor: password1 !== password2 && password2 !== '' ? 'rgba(255, 0, 0, 0.228)' : '' }} type={"password"} id="outlined-basic" label="Password" variant="outlined"></TextField>



                <TextField onChange={(e) => {
                    setName(e.target.value)
                    setFlagName(true)
                    if (flagCheckEmail && flagCheckPassword && flagName) {
                        setFlagHidden(false)
                    }
                }} type={"text"} id="outlined-basic" label="Name" variant="outlined"></TextField>


                <Button hidden={flagHidden} style={{ width: "100%", height: "5vh" }} onClick={btnSubmitRegister}>Login</Button> <br />


            </div>

            <Snackbar
                style={{ marginTop: '220px' }}
                anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
                open={open}
                autoHideDuration={1000}
                onClose={handleClose}
                message={message}
            />
        </div >
    )
}

