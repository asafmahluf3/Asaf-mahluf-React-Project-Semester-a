import React, { useContext } from 'react'
import { ProductsContext } from '../Context/ListProductsContextProvider'

export default function FCProductCart(props) {

    const { removeFromitemsInCart } = useContext(ProductsContext)


    const fromCartClickX = () => {
        removeFromitemsInCart(props.id, props.price)
    }

    return (
        <div style={{ border: "1px solid white", width: 250,background:"white" }}>
            {props.name} <br />
            {props.price}$ <br />
            <img style={{ width: "100%" }} src={props.img} alt="" /> <br />
            <button style={{background:"none",border:"0px"}} onClick={() => fromCartClickX(props)}>❌</button>
        </div>
    )
}
