import { Snackbar } from '@mui/material'
import React, { useContext, useState } from 'react'
import { NewsContext } from '../Context/NewsContextProvider'


export default function FCAdminAddNews() {
    const [title, setTitle] = useState('')
    const [firstParagraph, setFirstParagraph] = useState('')
    const [secondParagraph, setSecondParagraph] = useState('')
    const [mainImage, setMainImage] = useState('')
    const [secondImage, setSecondImage] = useState('')
    const [mainImagePreviewUrl, setMainImagePreviewUrl] = useState(null)
    const [secondImagePreviewUrl, setSecondImagePreviewUrl] = useState(null)


    const [open, setOpen] = useState(false)
    const [message, setMessage] = useState('')


    const { addToNews } = useContext(NewsContext)


    const btnAddNews = () => {
        let MessegeToShow = addToNews(mainImage, secondImage, title, firstParagraph, secondParagraph)

        if (MessegeToShow === "MessegeSomethingempty") {
            setMessage("Something empty")
            setOpen(true)
        }
        else if (MessegeToShow === "Messegeyourparagraphtoolong") {
            setMessage("your paragraph too long")
            setOpen(true)
        }
        else if (MessegeToShow === "MessegeNewsAdd") {
            setMessage("News Add")
            setOpen(true)
        }



    }


    const handleMainImageChange = (e) => {
        const file = e.target.files[0]
        setMainImage(file)
        const reader = new FileReader()
        reader.onloadend = () => {
            setMainImagePreviewUrl(reader.result)
            setMainImage(reader.result)
        }
        reader.readAsDataURL(file)
    }


    const handleSecondImageChange = (e) => {
        const file = e.target.files[0]
        setSecondImage(file)
        const reader = new FileReader()
        reader.onloadend = () => {
            setSecondImagePreviewUrl(reader.result)
            setSecondImage(reader.result)
        }
        reader.readAsDataURL(file)
    }

    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
            return
        }
        setOpen(false)
    }

    return (
        <div style={{ background: "linear-gradient(to right, rgb(255, 255, 255), #835B00)", width: "100%", padding: "50px 25px 50px 25px", display: "flex", flexDirection: "column", gap: "15px" }}>
            <h1 style={{ color: "lightblue" }}>𝓐𝓭𝓭 𝓝𝓮𝔀</h1>


            <input placeholder='Title' onChange={(e) => setTitle(e.target.value)}></input>

            <input placeholder='First Paragraph' onChange={(e) => setFirstParagraph(e.target.value)}></input>

            <div style={{ fontSize: "10px", paddingRight: "90%", marginTop: "-15px", color: "black" }}>
                {firstParagraph.length} / 420
            </div>

            <input placeholder='Second Paragraph' onChange={(e) => setSecondParagraph(e.target.value)}></input>

            <div style={{ fontSize: "10px", paddingRight: "90%", marginTop: "-15px", color: "black" }}>
                {secondParagraph.length} / 420
            </div>

            <input type="file" onChange={handleMainImageChange} />
            <img style={{ width: "300px" }} src={mainImagePreviewUrl} />

            <input type="file" onChange={handleSecondImageChange} />
            <img style={{ width: "300px" }} src={secondImagePreviewUrl} />



            <button style={{ background: "lightblue", padding: "8px 25px", borderRadius: "4px", color: "#FFF", fontWeight: "bold", fontSize: "14px", cursor: "pointer", textDecoration: "none" }} onClick={btnAddNews}>Add New</button> <br />



            <Snackbar
                style={{ marginTop: '170px' }}
                anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
                open={open}
                autoHideDuration={1000}
                onClose={handleClose}
                message={message}
            />

        </div >
    )
}
