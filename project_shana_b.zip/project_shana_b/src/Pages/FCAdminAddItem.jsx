import { Snackbar } from '@mui/material';
import React, { useContext, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ProductsContext } from '../Context/ListProductsContextProvider'

export default function FCAdminAddItem() {
  const { addToItemsFromAddProduct } = useContext(ProductsContext)
  const navigate = useNavigate();

  const [name, setName] = useState('')
  const [price, setPrice] = useState('')
  const [img, setImg] = useState('')

  const [open, setOpen] = useState(false)
  const [message, setMessage] = useState('')

  const btnAddProduct = () => {
    parseInt(price)
    if (name !== '' && price > 0 && img !== '') {
      addToItemsFromAddProduct(name, price, img)
      setMessage("Item added")
      setOpen(true)
      navigate('/shop')
    }
    else {
      setMessage("Something empty")
      setOpen(true)
      
    }
  }
  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
        return
    }
    setOpen(false)
}

  const handleKeyDown = (event) => {
    if (event.key === 'Enter') {
      btnAddProduct()
    }
  }

  return (
    <div style={{ width: "40%", display: "block", position: "absolute", top: "20%", left: "28%", justifyContent: "center", alignContent: "center" }}>
      <div style={{ background: "linear-gradient(to right, rgb(255, 255, 255), #835B00)", width: "100%", padding: "50px 25px 50px 25px", display: "flex", flexDirection: "column", gap: "15px" }}>
        <div>
          <h1 style={{ color: "lightblue" }}>𝒜𝒹𝒹 𝒫𝓇𝑜𝒹𝓊𝒸𝓉 </h1>
          <input placeholder='Enter Name' type="text" onChange={(e) => setName(e.target.value)} onKeyDown={handleKeyDown} /> <br />
          <input placeholder='Enter Price' type="text" onChange={(e) => setPrice(e.target.value)} onKeyDown={handleKeyDown} /> <br />
          <input placeholder='Enter image URL' type="url" onChange={(e) => setImg(e.target.value)} onKeyDown={handleKeyDown} /> <br /> <br />
          <button style={{ background: "lightblue", padding: "8px 25px", borderRadius: "4px", color: "#FFF", fontWeight: "bold", fontSize: "14px", cursor: "pointer", textDecoration: "none" }} onClick={btnAddProduct}>Add Item</button> <br />

        </div>
      </div>
      <Snackbar
                style={{ marginTop: '100px' }}
                anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
                open={open}
                autoHideDuration={1000}
                onClose={handleClose}
                message={message}
            />
    </div>
  )
}
