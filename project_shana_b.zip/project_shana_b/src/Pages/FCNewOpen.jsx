import React, { useContext } from 'react';
import { NewsContext } from '../Context/NewsContextProvider';


export default function FCNewOpen() {

  const { newOpenInBig } = useContext(NewsContext)


  const btnShow = () => {
    console.log(newOpenInBig);
  }

  return (
    <div>
      <h1>{newOpenInBig.title}</h1>

      <div style={{ marginTop: "10%",width:"1000px",fontSize:"22px" }}>


        <div style={{ display: "flex", height: "40vh"}}>

          <div style={{ width: "50%", display: "flex", justifyContent: "left", alignItems: "left" }}>
            <img style={{ width: "90%" }} src={newOpenInBig.mainImage} alt="" />
          </div>

          <div style={{ width: "50%", display: "flex", justifyContent: "center", alignItems: "center" }}>
            {newOpenInBig.firstParagraph}
          </div>


        </div>

        <br />
        <br />

        
        <div style={{ display: "flex", height: "40vh" }}>

          <div style={{ width: "50%", display: "flex", justifyContent: "center", alignItems: "center" }}>
            {newOpenInBig.secondParagraph}
          </div>


          <div style={{ width: "50%", display: "flex", justifyContent: "right", alignItems: "right" }}>
            <img style={{ width: "90%" }} src={newOpenInBig.secondImage} alt="" />
          </div>



        </div>




      </div>
      <br />
    </div>
  )
}
