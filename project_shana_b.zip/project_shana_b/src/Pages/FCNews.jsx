import React, { useContext } from 'react'
import { NewsContext } from '../Context/NewsContextProvider';
import FCSoloNew from './FCSoloNew';





export default function FCNews() {


    const { news } = useContext(NewsContext)



    let strNews = news.map(avi =>
        <FCSoloNew
            key={avi.id}
            id={avi.id}
            mainImage={avi.mainImage}
            title={avi.title}
            firstParagraph={avi.firstParagraph}
        />
    )

    return (

        <div style={{ background: "linear-gradient(to right, rgba(173, 216, 230, 0), rgba(173, 216, 230, 0))", width: "1100px", height: "100%", padding: "50px 25px 50px 25px", display: "flex", flexDirection: "column", gap: "15px" }}>
            <h1 style={{ color: "lightblue" }}>NEWS</h1>

            <div style={{ width: "100%", display: "flex", gap: "150px", flexWrap: "wrap", justifyItems: "center", justifyContent: "center", flexDirection: "column" }}>
                {strNews}
            </div>



        </div>
    )
}
