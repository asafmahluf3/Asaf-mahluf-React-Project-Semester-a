import { Snackbar } from '@mui/material';
import React, { useContext, useState } from 'react'
import { useNavigate } from 'react-router-dom';
import { ProductsContext } from '../Context/ListProductsContextProvider'
import { UserContext } from '../Context/UserContextProvider';
import FCProduct from './FCProduct';

export default function FCShop() {

  const navigate = useNavigate();


  const { items } = useContext(ProductsContext)
  const { currentUser } = useContext(UserContext)

  const [open, setOpen] = useState(false)
  const [message, setMessage] = useState('')



  let strItems = items.map(avi =>
    <FCProduct
      key={avi.id}
      id={avi.id}
      name={avi.name}
      price={avi.price}
      img={avi.img}
    />
  )

  const btnGoToCart = () => {
    if (currentUser !== null && currentUser !== undefined) {
      navigate('/cart')
    }
    else {
      setMessage("LOGIN BEOFRE")
      setOpen(true)
    }
  }

  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return
    }
    setOpen(false)
  }


  return (

    <div style={{ color: "lightblue", width: "100%" }}>
      <img onClick={btnGoToCart} style={{ position: "absolute", top: "100px", right: "15px", width: "70px", marginBottom: "20px" }} src="https://cdn-icons-png.flaticon.com/512/3916/3916598.png" alt="" />
      <h1 >𝓢𝓱𝓸𝓹</h1>
      <div style={{ display: "flex", gap: "15px", flexWrap: "wrap", justifyItems: "center", justifyContent: "center" }}>
        {strItems}
      </div>
      <Snackbar
        style={{ marginTop: '220px' }}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
        open={open}
        autoHideDuration={1000}
        onClose={handleClose}
        message={message}
      />
    </div>
  )
}
