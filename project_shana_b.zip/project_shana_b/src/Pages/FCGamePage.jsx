import React from 'react'

export default function FCGamePage() {

    return (
        <div style={{ width: "100%" }}>
            <h1 style={{ fontSize: '30px', color: 'red', textTransform: 'uppercase', letterSpacing: '5px' }}>
                If you're feeling a bit bored, why not try out our MAZE?
            </h1>
            <h2 style={{ fontSize: '20px', color: 'blue', fontWeight: 'bold' }}>
                Get ready to put your skills to the test and navigate through our challenging maze!
            </h2>
            <span role="img" aria-label="controller">🕹️</span>
            <span role="img" aria-label="video-game">🎮</span>
            <span role="img" aria-label="alien-monster">👾</span>
            <iframe style={{ width: "2000px", height: "750px" }} src="https://resplendent-frangollo-447c14.netlify.app/" frameBorder="0"></iframe>
        </div>
    )
}
