import React, { useContext } from 'react'
import { ProductsContext } from '../Context/ListProductsContextProvider'
import FCProductCart from './FCProductCart'

export default function FCCart() {

    const { itemsInCart, totalPrice } = useContext(ProductsContext)

    let strItemsInCart = itemsInCart.map(avi =>
        <FCProductCart
            key={avi.id}
            id={avi.id}
            name={avi.name}
            price={avi.price}
            img={avi.img}
        />
    )

    return (


        <div style={{ width: "100%",color:"lightblue" }}>
            <h1 style={{ color: "lightblue" }}>𝓒𝓪𝓻𝓽</h1>
            <div style={{ display: "flex", gap: "15px", flexWrap: "wrap", justifyItems: "center", justifyContent: "center" }}>
                {strItemsInCart}
            </div >
            Total price: {totalPrice}$
        </div>



    )
}
